﻿using Extensions.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace hashmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string data = "Hello, World!"; // Data to be hashed
            MessageBox.Show(xxhash(data, XXHash32.Create()));
            MessageBox.Show(xxhash(data, XXHash64.Create()));
            
        }
        static string xxhash(string input,HashAlgorithm algorithm)
        {
            byte[] data=Encoding.UTF8.GetBytes(input);
            byte[] result=algorithm.ComputeHash(data);
            StringBuilder sb=new StringBuilder();
            foreach(byte b in result.Reverse() )
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }
        

    }
}
